@extends('layout/main')
@section('title', 'Rooms')
@section('container')
     
<div class="container">
   <div class="row">
       <div class="col-10">
           <h1>Room</h1>
       </div>
   </div>
</div>    
@endsection

  