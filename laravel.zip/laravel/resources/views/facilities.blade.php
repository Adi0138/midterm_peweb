@extends('layout/main')
@section('title', 'Our Facilities')
@section('container')
     
<div class="container">
   <div class="row">
       <div class="col-10">
           <h1>Facilities</h1>
       </div>
   </div>
</div>    
@endsection

  