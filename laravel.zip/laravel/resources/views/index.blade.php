 @extends('layout/main')
 @section('title', 'ITS Hotel')
 @section('container')
      
 <div class="container">
    <div class="row">
        <div class="col-10">
            <h1>Hello, world!</h1>
        </div>
    </div>
</div>    
@endsection

   