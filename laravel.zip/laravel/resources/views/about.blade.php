@extends('layout/main')
@section('title', 'About Us')
@section('container')
     
<div class="container">
   <div class="row">
       <div class="col-10">
           <h1>About Us</h1>
       </div>
   </div>
</div>    
@endsection

  